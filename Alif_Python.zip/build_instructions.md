# Build Alif exe using PyInstaller
1. Install PyInstaller:
   ```bash
   pip install pyinstaller
   ```
2. Open terminal in app directory
3. Run:
   ```bash
   pyinstaller --name Alif --onefile app.py
   ```
4. Find exe in `dist/Alif.exe`
5. Optional: create Desktop shortcut manually or using a script