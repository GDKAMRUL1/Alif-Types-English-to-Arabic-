#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# [Your Alif app.py code goes here, use previous code]