# Alif - English to Arabic Transliterator (Python)
## Quick start
1. Install Python 3.9+
2. Install required libraries:
   ```bash
   pip install -r requirements.txt
   ```
3. Run the app:
   ```bash
   python app.py
   ```
4. Optional: Use `build_instructions.md` to create exe with PyInstaller